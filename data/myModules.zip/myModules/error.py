## module error
''' err(string).
'''

import sys
def err(string):
    print(string)
    input("Press return to exit")
    sys.exit()
    
